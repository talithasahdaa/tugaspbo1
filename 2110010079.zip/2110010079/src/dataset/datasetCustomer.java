
package dataset;
import java.util.ArrayList;
        


public class datasetCustomer {
    
    private ArrayList<String> KodeCustomer;
    private ArrayList<String> Nama;
    private ArrayList<String> Alamat;
    private ArrayList<String> Kota;
    private ArrayList<String> Telepon;
    private ArrayList<String> HP;
    
    public datasetCustomer(){
        
        KodeCustomer = new ArrayList<String>();
        Nama = new ArrayList<String>();
        Alamat = new ArrayList<String>();
        Kota = new ArrayList<String>();
        Telepon = new ArrayList<String>();
        HP = new ArrayList<String>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordKodeCustomer(){
        return this.KodeCustomer;
    }
    
    public void insertKodeCustomer(String isi){
        this.KodeCustomer.add(isi);
    }
    
    public void insertNama (String isi){
        this.Nama.add(isi);
    }
    
    public ArrayList<String> getRecordNama(){
        return this.Nama;
    }
     
    public ArrayList<String> getRecordAlamat(){
        return this.Alamat;
    }
    
    public void insertAlamat (String isi){
        this.Alamat.add(isi);
    }
  
      public ArrayList<String> getRecordKota(){
        return this.Kota;
    }
    
    public void insertKota(String isi){
        this.Kota.add(isi);
    }
    public ArrayList<String> getRecordTelepon(){
        return this.Telepon;
    }
    
    public void insertTelepon (String isi){
        this.Telepon.add(isi);
    }
    
    public ArrayList<String> getRecordHP(){
        return this.HP;
    }
    
    public void insertHP (String isi){
        this.HP.add(isi);
    }
    
}
    
    
    
    
    
    
    
    
    
    

