
package dataset;
import java.util.ArrayList;
        


public class datasetHeaderPenjualan {
    
    private ArrayList<String> NoFaktur;
    private ArrayList<String> KodeCustomer;
    private ArrayList<Integer> Subtotal;
    private ArrayList<Integer> Diskon;
    private ArrayList<Integer> Total;
    private ArrayList<Integer> Bayar;
    private ArrayList<Integer> Sisa;
    
    public datasetHeaderPenjualan(){
        
        NoFaktur = new ArrayList<String>();
        KodeCustomer = new ArrayList<String>();
        Subtotal = new ArrayList<Integer>();
        Diskon = new ArrayList<Integer>();
        Total = new ArrayList<Integer>();
        Bayar = new ArrayList<Integer>();
        Sisa = new ArrayList<Integer>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordNoFaktur(){
        return this.NoFaktur;
    }
    
    public void insertNoFaktur(String isi){
        this.NoFaktur.add(isi);
    }
    
    public void insertKodeCustomer (String isi){
        this.KodeCustomer.add(isi);
    }
    
    public ArrayList<String> getRecordKodeCustomer(){
        return this.KodeCustomer;
    }
     
    public ArrayList<Integer> getRecordSubtotal(){
        return this.Subtotal;
    }
    
    public void insertSubtotal (int isi){
        this.Subtotal.add(isi);
    }
  
      public ArrayList<Integer> getRecordDiskon(){
        return this.Diskon;
    }
    
    public void insertDiskon(int isi){
        this.Diskon.add(isi);
    }
    public ArrayList<Integer> getRecordTotal(){
        return this.Total;
    }
    
    public void insertTotal (int isi){
        this.Total.add(isi);
    }
    
    public ArrayList<Integer> getRecordBayar(){
        return this.Bayar;
    }
    
    public void insertBayar (int isi){
        this.Bayar.add(isi);
    }
    
    public ArrayList<Integer> getRecordSisa(){
        return this.Sisa;
    }
    
    public void insertSisa (int isi){
        this.Sisa.add(isi);
    }
}
    
    
    
    
    
    
    
    
    
    

