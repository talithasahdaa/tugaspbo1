
package dataset;
import java.util.ArrayList;
        


public class datasetJenis {
    
    private ArrayList<String> KodeJenis;
    private ArrayList<String> Nama;
    
    public datasetJenis(){
        
        KodeJenis = new ArrayList<String>();
        Nama = new ArrayList<String>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordKodeJenis(){
        return this.KodeJenis;
    }
    
    public void insertKodeJenis(String isi){
        this.KodeJenis.add(isi);
    }
        
    public ArrayList<String> getRecordNama(){
        return this.Nama;
    }
    
        public void insertNama (String isi){
        this.Nama.add(isi);
    }
    
}
    
    
    
    
    
    
    
    
    
    

