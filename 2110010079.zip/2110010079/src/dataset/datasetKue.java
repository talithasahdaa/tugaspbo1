
package dataset;
import java.util.ArrayList;
        


public class datasetKue {
    
    private ArrayList<String> Kodekue;
    private ArrayList<String> KodeJenis;
    private ArrayList<Integer> HargaReseller;
    private ArrayList<Integer> HargaCustomer;
    private ArrayList<Integer> Qty;
    private ArrayList<Integer> SaldoMinimum;
    
    public datasetKue(){
        
        Kodekue = new ArrayList<String>();
        KodeJenis = new ArrayList<String>();
        HargaReseller = new ArrayList<Integer>();
        HargaCustomer = new ArrayList<Integer>();
        Qty = new ArrayList<Integer>();
        SaldoMinimum = new ArrayList<Integer>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordKodeKue(){
        return this.Kodekue;
    }
    
    public void insertKodeKue(String isi){
        this.Kodekue.add(isi);
    }
        
    public ArrayList<String> getRecordKodeJenis(){
        return this.KodeJenis;
    }

    public void insertKodeJenis (String isi){
        this.KodeJenis.add(isi);
    }    
    
    public ArrayList<Integer> getRecordHargaReseller(){
        return this.HargaReseller;
    }
    
    public void insertHargaReseller (int isi){
        this.HargaReseller.add(isi);
    }
  
    public ArrayList<Integer> getRecordHargaCustomer(){
        return this.HargaCustomer;
    }
    
    public void insertHargaCustomer(int isi){
        this.HargaCustomer.add(isi);
    }
    public ArrayList<Integer> getRecordQty(){
        return this.Qty;
    }
    
    public void insertQty (int isi){
        this.Qty.add(isi);
    }
    
    public ArrayList<Integer> getRecordSaldoMinimum(){
        return this.SaldoMinimum;
    }
    
    public void insertSaldoMinimum (int isi){
        this.SaldoMinimum.add(isi);
    }
    
}