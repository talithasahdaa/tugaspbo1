
package dataset;
import java.util.ArrayList;
        


public class datasetSupplier {
    
    private ArrayList<String> KodeSupplier;
    private ArrayList<String> Nama;
    private ArrayList<String> Alamat;
    private ArrayList<String> Kota;
    private ArrayList<String> Telepon;
    private ArrayList<String> HP;
    
    public datasetSupplier(){
        
        KodeSupplier = new ArrayList<String>();
        Nama = new ArrayList<String>();
        Alamat = new ArrayList<String>();
        Kota = new ArrayList<String>();
        Telepon = new ArrayList<String>();
        HP = new ArrayList<String>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordKodeSupplier(){
        return this.KodeSupplier;
    }
    
    public void insertKodeSupplier(String isi){
        this.KodeSupplier.add(isi);
    }
    
    public void insertNama (String isi){
        this.Nama.add(isi);
    }
    
    public ArrayList<String> getRecordNama(){
        return this.Nama;
    }
     
    public ArrayList<String> getRecordAlamat(){
        return this.Alamat;
    }
    
    public void insertAlamat (String isi){
        this.Alamat.add(isi);
    }
  
      public ArrayList<String> getRecordKota(){
        return this.Kota;
    }
    
    public void insertKota(String isi){
        this.Kota.add(isi);
    }
    public ArrayList<String> getRecordTelepon(){
        return this.Telepon;
    }
    
    public void insertTelepon (String isi){
        this.Telepon.add(isi);
    }
    
    public ArrayList<String> getRecordHP(){
        return this.HP;
    }
    
    public void insertHP (String isi){
        this.HP.add(isi);
    }
    
}
    
    
    
    
    
    
    
    
    
    

