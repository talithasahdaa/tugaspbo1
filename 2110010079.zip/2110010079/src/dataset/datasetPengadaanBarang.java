
package dataset;
import java.util.ArrayList;
        


public class datasetPengadaanBarang {
    
    private ArrayList<String> NoFaktur;
    private ArrayList<String> KodeSupplier;
    private ArrayList<Integer> Subtotal;
    private ArrayList<Integer> Diskon;
    private ArrayList<Integer> Total;
    private ArrayList<Integer> Bayar;
    private ArrayList<Integer> Sisa;
    
    public datasetPengadaanBarang(){
        
        NoFaktur = new ArrayList<String>();
        KodeSupplier = new ArrayList<String>();
        Subtotal = new ArrayList<Integer>();
        Diskon = new ArrayList<Integer>();
        Total = new ArrayList<Integer>();
        Bayar = new ArrayList<Integer>();
        Sisa = new ArrayList<Integer>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordNoFaktur(){
        return this.NoFaktur;
    }
    
    public void insertNoFaktur(String isi){
        this.NoFaktur.add(isi);
    }
    
    public void insertKodeSupplier (String isi){
        this.KodeSupplier.add(isi);
    }
    
    public ArrayList<String> getRecordKodeSupplier(){
        return this.KodeSupplier;
    }
     
    public ArrayList<Integer> getRecordSubtotal(){
        return this.Subtotal;
    }
    
    public void insertSubtotal (int isi){
        this.Subtotal.add(isi);
    }
  
      public ArrayList<Integer> getRecordDiskon(){
        return this.Diskon;
    }
    
    public void insertDiskon(int isi){
        this.Diskon.add(isi);
    }
    public ArrayList<Integer> getRecordTotal(){
        return this.Total;
    }
    
    public void insertTotal (int isi){
        this.Total.add(isi);
    }
    
    public ArrayList<Integer> getRecordBayar(){
        return this.Bayar;
    }
    
    public void insertBayar (int isi){
        this.Bayar.add(isi);
    }
    
    public ArrayList<Integer> getRecordSisa(){
        return this.Sisa;
    }
    
    public void insertSisa (int isi){
        this.Sisa.add(isi);
    }
}
    
    
    
    
    
    
    
    
    
    

