
package dataset;
import java.util.ArrayList;
        


public class datasetDetailPengadaan {
    
    private ArrayList<String> NoFaktur;
    private ArrayList<String> KodeKue;
    private ArrayList<Integer> Qty;
    private ArrayList<Integer> Hsatuan;
    private ArrayList<Integer> Total;
    
    public datasetDetailPengadaan(){
        
        NoFaktur = new ArrayList<String>();
        KodeKue = new ArrayList<String>();
        Qty = new ArrayList<Integer>();
        Hsatuan = new ArrayList<Integer>();
        Total = new ArrayList<Integer>();
        
    }
    
//    public void insertNip(String isi){
//        this.nip.add(isi);
//    }
    
    public ArrayList<String> getRecordNoFaktur(){
        return this.NoFaktur;
    }
    
    public void insertNoFaktur(String isi){
        this.NoFaktur.add(isi);
    }
    
    public void insertKodeKue (String isi){
        this.KodeKue.add(isi);
    }
    
    public ArrayList<String> getRecordKodeKue(){
        return this.KodeKue;
    }
     
    public ArrayList<Integer> getRecordQty(){
        return this.Qty;
    }
    
    public void insertQty (int isi){
        this.Qty.add(isi);
    }
  
      public ArrayList<Integer> getRecordHsatuan(){
        return this.Hsatuan;
    }
    
    public void insertHsatuan(int isi){
        this.Hsatuan.add(isi);
    }
    public ArrayList<Integer> getRecordTotal(){
        return this.Total;
    }
    
    public void insertTotal (int isi){
        this.Total.add(isi);
    }
    
}
    
    
    
    
    
    
    
    
    
    

