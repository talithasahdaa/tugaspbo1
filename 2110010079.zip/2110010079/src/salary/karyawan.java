/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author LENOVO
 */
public class karyawan extends penggajian{
    
    private String nip;
    private String nama;
    
    public karyawan(){}
    
    public void setNip(String nip){
        this.nip = nip;
    }
    
    public String getNip(){
        return this.nip;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return this.nama;
    }
    
}
