/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author LENOVO
 */
public class penggajian {
    
    private int tunjStatusMenikah; //field global
    private int tunjJumlahAnak;
    private int tunjMasaKerja;
    private int tunjGolongan;
    
    public penggajian(){}//constructor
    
    public penggajian(String status){
        setStatusMenikah(status);
    }//constructor
    public penggajian(String status, int golongan){
        setStatusMenikah(status);
        setGolongan(tunjGolongan);
    }
    public penggajian(String status, int golongan, int masa){
        setStatusMenikah(status);
        setGolongan(tunjGolongan);
        setMasaKerja(masa);
    }                           //OVERLOAD CONSTRUCTOR
    public penggajian(String status, int golongan, int masa, int jumlah){
        setStatusMenikah(status);
        setGolongan(golongan);
        setMasaKerja(masa);
        setJumlahAnak(jumlah);
    }
    
    public penggajian(int says){
        System.out.println(says);
            }
    public void setStatusMenikah(String status){
        if (status.equals("Menikah"))
            this.tunjStatusMenikah=1000000 ;
        else {
            this.tunjStatusMenikah=150000 ;
        }
    }
    public int gettunjStatusMenikah(){
        return this.tunjStatusMenikah;
    }
    
    public void setJumlahAnak(int jumlah){
        if (jumlah==0){
            this.tunjJumlahAnak = 0;
        }else if (jumlah >= 1 && jumlah <= 3){
            this.tunjJumlahAnak = 500000;
        }else if (jumlah >= 4 && jumlah <= 6){
            this.tunjJumlahAnak = 750000;}
        else{
            this.tunjJumlahAnak = 900000;}
        
    }
    public int getTunjJumlahAnak(){
        return this.tunjJumlahAnak;
    }
    
    public void setMasaKerja(int lama){
        if (lama >= 0 && lama <= 3){
            this.tunjMasaKerja = 400000;
        }else if (lama >= 4 && lama <= 8){
            this.tunjMasaKerja = 700000;
        }else {
            this.tunjMasaKerja = 1000000;}
    }
    
    public int getTunjMasaKerja(){
        return this.tunjMasaKerja;
    }
    
    public void setGolongan(int golongan){//menggunakan switch karena ada pesan pada saat koding if
        switch (golongan) {
            case 1:
                this.tunjGolongan = 3500000;
                break;
            case 2:
                this.tunjGolongan = 4000000;
                break;
            case 3:
                this.tunjGolongan = 4500000;
                break;
    }
    }
    
    public int getTunjGolongan(){
        return this.tunjGolongan;
    }
    
    public int gajiTotal(){
        return getTunjGolongan()+ getTunjJumlahAnak()+ gettunjStatusMenikah()+ getTunjMasaKerja();
    }
    
    public int gajiTotal(String x, int y, int z, int j){
        setStatusMenikah(x);
        setGolongan(y);
        setMasaKerja(z);
        setJumlahAnak(j);
        return getTunjGolongan()+ getTunjJumlahAnak()+ gettunjStatusMenikah()+ getTunjMasaKerja();
    }
}

    