/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum4d;
import java.util.ArrayList;
import dataset. *;
import salary. *;
import forms.*;
/**
 *
 * @author LENOVO
 */
public class Praktikum4d {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        // TODO code application logic here
//        penggajian objku = new penggajian();
//        objku.setStatusMenikah("Menikah");
//        
//        System.out.println("Tunjangan Status "+objku.gettunjStatusMenikah());
//        
//        objku.setJumlahAnak(2);
//        
//        System.out.println("Tunjangan Anak "+objku.getTunjJumlahAnak());
//        
//        objku.setMasaKerja(5);
//        
//        System.out.println("Tunjangan Kerja "+objku.getTunjMasaKerja());
//        
//        objku.setGolongan(2);
//        
//        System.out.println("Tunjangan Kerja "+objku.getTunjGolongan());
//        
//        System.out.println("Gaji total :" +objku.gajiTotal());

//    karyawan tes = new karyawan();
//    tes.setNip("2110010616");
//    tes.setNama("M. Ziyad Rahmani");
//    tes.setGolongan(1);
//    tes.setMasaKerja(3);
//    tes.setStatusMenikah("Belum Menikah");
//    tes.setJumlahAnak(0);
//    System.out.println("NIP : "+tes.getNip());
//    System.out.println("Nama : "+tes.getNama());
//    System.out.println("Tunjangan Golongan : "+tes.getTunjGolongan());
//    System.out.println("Tunjangan Masa Kerja : "+tes.getTunjMasaKerja());
//    System.out.println("Tunjangan Status Menikah : "+tes.gettunjStatusMenikah());
//    System.out.println("Tunjangan Jumlah Anak : "+tes.getTunjJumlahAnak());
//    System.out.println("Gaji Total : "+tes.gajiTotal());

//     String[] kota={"Banjarmasin","Banjarbaru","Martapura","Kotabaru"};
//     System.out.println("Panjang Array Kota : "+kota.length);
//     System.out.println("Kota ke-2 : "+kota[2]);
//     
//     int[] npm = new int[3];
//     npm[0]=2110010616;
//     npm[1]=2110010632;
//     npm[2]=2110019423;
//     System.out.println("Panjang Array npm :"+npm.length);
//     System.out.println("Nilai NPM ke-1 : "+npm[1]);
//     System.out.println("Nilai NPM ke-3 : "+npm[3]);
     
//     ArrayList<String> provinsi = new ArrayList<String>();
//     provinsi.add("Kalimantan Selatan");
//     provinsi.add("Jakarta");
//     provinsi.add("Jawa Timur");
//     System.out.println("Jumlah Arraylist Provinsi : "+provinsi.size());
//     System.out.println(provinsi);
//     System.out.println(provinsi.get(0));
//     provinsi.remove(0);
//     System.out.println("Jumlah Arraylist Provinsi : "+provinsi.size());
//     System.out.println(provinsi.get(0));

//    ArrayList<Integer> npm = new ArrayList<Integer>();
//    npm.add(2110010616);
//    npm.add(2110010231);
//    System.out.println(npm);

//    datasetKaryawan uji = new datasetKaryawan();
//    uji.insertNip("21109123");
//    uji.insertNip("20912312");
//    System.out.println(uji.getRecordNip().get(1));
//    

new frameUtama().setVisible(true);

}    
    
}
